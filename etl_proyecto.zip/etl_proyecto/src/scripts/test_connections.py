# test_connections.py
from sqlalchemy import create_engine, text
import os
from dotenv import load_dotenv

# Carga el .env desde la raíz del proyecto
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(BASE_DIR, ".env"))

PG_URL    = f"postgresql+psycopg2://{os.getenv('PG_USER')}:{os.getenv('PG_PASS')}@{os.getenv('PG_HOST','127.0.0.1')}:{os.getenv('PG_PORT','5432')}/{os.getenv('PG_DB')}"
MYSQL_URL = f"mysql+pymysql://{os.getenv('MYSQL_USER')}:{os.getenv('MYSQL_PWD')}@{os.getenv('MYSQL_HOST','127.0.0.1')}:{os.getenv('MYSQL_PORT','3306')}/{os.getenv('MYSQL_DB')}?charset=utf8mb4"
DWH_URL   = f"mysql+pymysql://{os.getenv('DWH_USER')}:{os.getenv('DWH_PASS')}@{os.getenv('DWH_HOST','127.0.0.1')}:{os.getenv('DWH_PORT','3306')}/{os.getenv('DWH_DB')}?charset=utf8mb4"

def check(name, url):
    try:
        eng = create_engine(url, pool_pre_ping=True)
        with eng.connect() as c:
            c.execute(text("SELECT 1"))
        print(f"[OK] {name}")
    except Exception as e:
        print(f"[ERROR] {name} -> {e}")

if __name__ == "__main__":
    check("Postgres RH", PG_URL)
    check("MySQL Ventas", MYSQL_URL)
    check("MySQL DWH", DWH_URL)
