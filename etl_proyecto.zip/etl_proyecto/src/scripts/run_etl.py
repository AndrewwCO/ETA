print("RUN_ETL: módulo cargado")

import os
from datetime import datetime
from urllib.parse import quote_plus

import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv, find_dotenv

# --- Carga .env ---
load_dotenv(find_dotenv(), encoding="utf-8")

# --- URLs seguras (soporta contraseñas con símbolos) ---
PG_USER = os.getenv("PG_USER", "postgres")
PG_PASS = quote_plus(os.getenv("PG_PASS", ""))
PG_HOST = os.getenv("PG_HOST", "127.0.0.1")
PG_PORT = os.getenv("PG_PORT", "5432")
PG_DB   = os.getenv("PG_DB", "recursos_humanos")

MYSQL_USER = os.getenv("MYSQL_USER", "ventas_user")
MYSQL_PWD  = quote_plus(os.getenv("MYSQL_PWD", ""))
MYSQL_HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
MYSQL_PORT = os.getenv("MYSQL_PORT", "3306")
MYSQL_DB   = os.getenv("MYSQL_DB", "ventas")

DWH_USER = os.getenv("DWH_USER", "root")
DWH_PASS = quote_plus(os.getenv("DWH_PASS", ""))
DWH_HOST = os.getenv("DWH_HOST", "127.0.0.1")
DWH_PORT = os.getenv("DWH_PORT", "3306")
DWH_DB   = os.getenv("DWH_DB", "dwh")

PG_URL    = f"postgresql+psycopg2://{PG_USER}:{PG_PASS}@{PG_HOST}:{PG_PORT}/{PG_DB}"
MYSQL_URL = f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PWD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}?charset=utf8mb4"
DWH_URL   = f"mysql+pymysql://{DWH_USER}:{DWH_PASS}@{DWH_HOST}:{DWH_PORT}/{DWH_DB}?charset=utf8mb4"

# --- Engines ---
pg_eng    = create_engine(PG_URL, connect_args={"options": "-c client_encoding=UTF8"})
mysql_eng = create_engine(MYSQL_URL, pool_pre_ping=True)
dwh_eng   = create_engine(DWH_URL,  pool_pre_ping=True)

def norm_str(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip()

def run():
    t0 = datetime.now()
    print("== ETL iniciado:", t0)

    # ===== EXTRACCIÓN =====
    print("Leyendo RH (Postgres)...")
    sql_rh = """
    SELECT
        e.employee_id           AS id_vendedor,
        e.first_name            AS nombre_vendedor,
        e.last_name             AS apellido_vendedor,
        j.job_title             AS cargo,
        d.department_name       AS departamento,
        l.city                  AS ciudad,
        l.state_province        AS estado,
        c.country_name          AS pais,
        r.region_name           AS region
    FROM employees e
    JOIN jobs j             ON e.job_id = j.job_id
    LEFT JOIN departments d ON e.department_id = d.department_id
    LEFT JOIN locations l   ON d.location_id = l.location_id
    LEFT JOIN countries c   ON l.country_id  = c.country_id
    LEFT JOIN regions r     ON c.region_id   = r.region_id
    """
    df_rh = pd.read_sql(sql_rh, pg_eng)
    print(f"RH filas: {len(df_rh)}")

    print("Leyendo Ventas (MySQL)...")
    sql_ventas = """
    SELECT
        dp.id_detalle,
        p.id_pedido                AS id_venta,
        pr.id_producto,
        pr.nombre                  AS nombre_producto,
        pr.categoria,
        dp.cantidad,
        dp.precio_unitario,
        (dp.cantidad * dp.precio_unitario) AS total_bruto,
        p.fecha_venta,
        p.id_vendedor,
        p.canal,
        p.metodo_pago,
        p.numero_factura
    FROM detalles_pedido dp
    JOIN pedidos p    ON dp.id_pedido   = p.id_pedido
    JOIN productos pr ON dp.id_producto = pr.id_producto
    """
    df_ventas = pd.read_sql(sql_ventas, mysql_eng)
    print(f"Ventas filas: {len(df_ventas)}")

    # ===== LIMPIEZA =====
    for col in ["nombre_producto","categoria","ciudad","estado","pais","region",
                "nombre_vendedor","apellido_vendedor","cargo","departamento",
                "canal","metodo_pago","numero_factura"]:
        if col in df_ventas.columns:  df_ventas[col] = norm_str(df_ventas[col])
        if col in df_rh.columns:      df_rh[col]     = norm_str(df_rh[col])

    df_ventas["fecha_venta"] = pd.to_datetime(df_ventas["fecha_venta"], errors="coerce").dt.date
    for c in ["cantidad","precio_unitario","total_bruto"]:
        if c in df_ventas.columns:
            df_ventas[c] = pd.to_numeric(df_ventas[c], errors="coerce").fillna(0)

    # ===== TRANSFORMACIÓN =====
    print("Unión Ventas + RH...")
    df_union = df_ventas.merge(df_rh, on="id_vendedor", how="left", validate="m:1")
    print("Filas unión:", len(df_union))

    # Dimensiones
    dim_producto = df_union[["id_producto","nombre_producto","categoria"]].drop_duplicates().reset_index(drop=True)
    dim_producto.insert(0, "sk_producto", range(1, len(dim_producto)+1))

    dim_ubicacion = df_union[["ciudad","estado","pais","region"]].drop_duplicates().reset_index(drop=True)
    dim_ubicacion.insert(0, "sk_ubicacion", range(1, len(dim_ubicacion)+1))

    dim_vendedor = df_union[["id_vendedor","nombre_vendedor","apellido_vendedor","cargo","departamento"]].drop_duplicates(subset=["id_vendedor"]).reset_index(drop=True)
    dim_vendedor.insert(0, "sk_vendedor", range(1, len(dim_vendedor)+1))

    dim_tiempo = (
        pd.DataFrame({"fecha": sorted(df_union["fecha_venta"].dropna().unique())})
        .assign(
            anio=lambda d: d["fecha"].apply(lambda x: x.year),
            mes=lambda d: d["fecha"].apply(lambda x: x.month),
            dia=lambda d: d["fecha"].apply(lambda x: x.day),
            trimestre=lambda d: d["fecha"].apply(lambda x: (x.month-1)//3 + 1),
        )
    )
    dim_tiempo.insert(0, "sk_fecha", range(1, len(dim_tiempo)+1))

    dim_venta_cols = [c for c in ["canal","metodo_pago","numero_factura"] if c in df_union.columns]
    dim_venta = (df_union[dim_venta_cols].drop_duplicates().reset_index(drop=True)
                 if dim_venta_cols else pd.DataFrame(columns=["canal","metodo_pago","numero_factura"]))
    dim_venta.insert(0, "sk_venta", range(1, len(dim_venta)+1))

    # Lookups
    f = df_union.merge(dim_producto[["sk_producto","id_producto"]], on="id_producto", how="left")
    f = f.merge(dim_vendedor[["sk_vendedor","id_vendedor"]], on="id_vendedor", how="left")
    f = f.merge(dim_ubicacion, on=["ciudad","estado","pais","region"], how="left")
    f = f.merge(dim_tiempo.rename(columns={"fecha":"fecha_venta"})[["sk_fecha","fecha_venta"]], on="fecha_venta", how="left")
    if not dim_venta.empty:
        f = f.merge(dim_venta, on=dim_venta_cols, how="left")

    f["ingreso_neto"] = f["total_bruto"]

    fact_cols = ["id_venta","id_detalle","sk_producto","sk_vendedor","sk_ubicacion","sk_fecha"]
    if "sk_venta" in f.columns: fact_cols.append("sk_venta")
    fact_cols += ["cantidad","precio_unitario","total_bruto","ingreso_neto"]
    fact_ventas = f[fact_cols].copy()

    # ===== CARGA =====
    print("Cargando dimensiones y hechos al DWH...")
    dim_producto.to_sql("dim_producto", dwh_eng, if_exists="append", index=False)
    dim_ubicacion.to_sql("dim_ubicacion", dwh_eng, if_exists="append", index=False)
    dim_vendedor.to_sql("dim_vendedor", dwh_eng, if_exists="append", index=False)
    dim_tiempo.to_sql("dim_tiempo", dwh_eng, if_exists="append", index=False)
    if not dim_venta.empty:
        dim_venta.to_sql("dim_venta", dwh_eng, if_exists="append", index=False)
    fact_ventas.to_sql("fact_ventas", dwh_eng, if_exists="append", index=False)

    # ===== CHECKS =====
    print("Dim producto / ubicacion / vendedor / tiempo / venta:",
          len(dim_producto), len(dim_ubicacion), len(dim_vendedor), len(dim_tiempo), len(dim_venta))
    print("Hechos:", len(fact_ventas))
    n_sk_null = fact_ventas[["sk_producto","sk_vendedor","sk_ubicacion","sk_fecha"]].isna().sum().to_dict()
    print("SKs nulos (deben ser 0):", n_sk_null)
    print("== ETL finalizado en:", datetime.now() - t0)

if __name__ == "__main__":
    print("RUN_ETL: entrando a main")
    try:
        run()
        print("RUN_ETL: fin OK")
    except Exception:
        import traceback
        print("RUN_ETL: ERROR")
        traceback.print_exc()
