CREATE DATABASE IF NOT EXISTS dwh
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE dwh;

CREATE TABLE IF NOT EXISTS dim_producto (
  sk_producto INT AUTO_INCREMENT PRIMARY KEY,
  id_producto INT,
  nombre_producto VARCHAR(255),
  categoria VARCHAR(255),
  UNIQUE KEY uk_dim_producto (id_producto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dim_ubicacion (
  sk_ubicacion INT AUTO_INCREMENT PRIMARY KEY,
  ciudad VARCHAR(255),
  estado VARCHAR(255),
  pais   VARCHAR(255),
  region VARCHAR(255),
  UNIQUE KEY uk_dim_ubicacion (ciudad, estado, pais, region)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dim_vendedor (
  sk_vendedor INT AUTO_INCREMENT PRIMARY KEY,
  id_vendedor INT,
  nombre_vendedor   VARCHAR(255),
  apellido_vendedor VARCHAR(255),
  cargo             VARCHAR(255),
  departamento      VARCHAR(255),
  UNIQUE KEY uk_dim_vendedor (id_vendedor)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dim_tiempo (
  sk_fecha INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE,
  anio INT,
  mes  TINYINT,
  dia  TINYINT,
  trimestre TINYINT,
  UNIQUE KEY uk_dim_tiempo (fecha)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dim_venta (
  sk_venta INT AUTO_INCREMENT PRIMARY KEY,
  canal           VARCHAR(100),
  metodo_pago     VARCHAR(100),
  numero_factura  VARCHAR(100),
  UNIQUE KEY uk_dim_venta (canal, metodo_pago, numero_factura)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fact_ventas (
  id_venta    INT,
  id_detalle  INT,
  sk_producto INT,
  sk_vendedor INT,
  sk_ubicacion INT,
  sk_fecha     INT,
  sk_venta     INT NULL,
  cantidad        DECIMAL(18,2),
  precio_unitario DECIMAL(18,2),
  total_bruto     DECIMAL(18,2),
  ingreso_neto    DECIMAL(18,2),
  INDEX ix_fecha (sk_fecha),
  INDEX ix_prod  (sk_producto),
  INDEX ix_vend  (sk_vendedor),
  INDEX ix_ubic  (sk_ubicacion),
  INDEX ix_venta (sk_venta),
  INDEX ix_idventa (id_venta, id_detalle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
